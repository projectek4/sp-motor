<ol class="breadcrumb breadcrumb-arrow">
	<li><?= anchor('', 'Beranda') ?> </li>
	<?php if (is_login()): ?>
	<li><?= anchor('edit/'.print_url(1), 'Edit data', array('class'=>'active')) ?></li>
	<?php endif ?>
	<li><?= anchor(current_url(), $title, array('class'=>'active')) ?></li>
	<!--<li class="active"><span>Data</span></li>-->
</ol>
<div style="position: relative;">
	<?php if (print_url(1) == 'edit'): ?>
		<?= form_open(current_url()) ?>
		<?= form_hidden('url', print_url(2)) ?>
		<?= $this->ckeditor->editor('content', html_entity_decode($content)) ?>
		<p></p>
		<?= form_button(array('class'=>'btn btn-lg btn-primary', 'type'=>'submit'), 'Update Data') ?>
		<?= form_close() ?>
	<?php else: ?>
		<article><?= $content ?></article>
	<?php endif ?>
</div>