
<html lang="en">
	<head>
		<title>Sistem Pakar<?= $title; ?></title><meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="resource-type" content="document" />
		<meta name="robots" content="all, index, follow"/>
		<meta name="googlebot" content="all, index, follow" />
    <!-- Le fav and touch icons -->
		<?= html_favicon() ?>
		<meta property="og:image" content="<?= base_url('assets/media/images/facebook-thumb.png'); ?>"/>
		<link rel="image_src" href="<?= base_url('assets/media/images/facebook-thumb.png'); ?>" />
	<?php
	/** -- Copy from here -- */
	if(!empty($meta))
	foreach($meta as $name=>$content){
		echo "\n\t\t";
		?><meta name="<?= $name; ?>" content="<?= $content; ?>" /><?php
			 }
	echo "\n";

	if(!empty($canonical))
	{
		echo "\n\t\t";
		?><link rel="canonical" href="<?= $canonical; ?>" /><?php

	}
	echo "\n\t";

	foreach($css as $file){
	 	echo "\n\t\t";
		?><link rel="stylesheet" href="<?= $file; ?>" type="text/css" /><?php
	} echo "\n\t";	

	foreach($less as $file){
	 	echo "\n\t\t";
		?><link rel="stylesheet" href="<?= $file; ?>" type="text/less" /><?php
	} echo "\n\t";

	/** -- to here -- */
?>
</head>

  <body>
  <span class="top-title">
  	<h1>Sistem Pakar Penyakit Radang Tenggorokan Pada Balita</h1>
  </span>
<nav class="navbar navbar-default">
	<!-- Brand and toggle get grouped for better mobile display -->
	<!--<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="#">Brand</a>
	</div>-->
	<!-- Collect the nav links, forms, and other content for toggling -->
	<div class="container">
	<div class="navbar-collapse navbar-right">
		<ul class="nav navbar-nav">
			<li><?= anchor('halaman-utama.html', html_media('1499325156_hospital.png').' Beranda'); ?></li>
			<li><?= anchor('profil-rumah-sakit.html', html_media('1499325166_medical_suitecase.png').' Profil'); ?></li>
			<li><?= (is_login()?anchor('pakar/penyakit', html_media('1499325143_stethoscope.png').' Pakar'):anchor('konsultasi', html_media('1499325143_stethoscope.png').' Konsultasi')); ?></li>
			<li><?= (is_login()?anchor('guestbook', html_media('1499330834_plant_no_shadwo.png').' Kotak saran'):anchor('kontak-kami.html', html_media('1499330834_plant_no_shadwo.png').' Tentang Kami')); ?></li>
			<?=(is_login()?'<li>'.anchor('logout', html_media('if_logout_63128.png').' Sign Out').'</li>':''); ?>
		</ul>
		</div><!-- /.navbar-collapse -->
	</div>

	</nav>
  <div class="container">
		<div class="row">
			<div style="min-height: 800px" class="col-sm-8">
			<?= $output ?></div>
			<div class="col-sm-4">
			<div class="side-panel"><h2>Kabar Soewondo</h2><ul class="wk-special">
			<?php
			error_reporting(0);
				$data = grab_url('http://rsud.patikab.go.id/index.php');
				$ex1 	= explode('<div class="blog-posts">', $data);
				$ex2 	= explode('</article>', $ex1[1]);
				//$ex3 	= explode('>', $ex2[1]);

				for ($i=0; $i < 4;) { 
				$list = $ex2[$i++]; //base
				$cari_link = explode('<h5 class="entry-title pt-0">', $list);
				$print_link = explode('</h5>', $cari_link[1]);

				$cari_img = explode('src="../', $list);
				$print_img = explode('"', $cari_img[1]);
				//$rep 	= str_replace('../uploaded', 'http://rsud.patikab.go.id/uploaded', $list);
				//echo str_replace('?page=berita&id', base_url('baca?berita'));
				//echo $list;
				echo '<li><h4>'.str_replace('href="?page=berita&id=', 'target ="_BLANK" href="//rsud.patikab.go.id/index.php?page=berita&id=', $print_link[0]).'</h4>' ;
				echo '</li>';
				}
			?></ul>
			<!--</ul><a class="main-site" target="_BLANK" href="http://rsud.patikab.go.id/"><span>>></span> Buka website RSUD RAA Soewondo</a> --><!-- </div> -->
			<a class="main-site" target="_BLANK" href="http://rsud.patikab.go.id/"><span>>></span> Buka website RSUD RAA Soewondo</a>
			</div>
			<div class="side-panel">
				<h2>Kontak Kami</h2>
				<ul>
					<li>Jl. Dr Soesanto No.114 Kodepos 59118 Pati</li>
					<li>Telepon : (0295) 381102 (5 Saluran)</li>
					<li>Faximile: (0295) 381684</li>
					<li>E-mail : brsdsoewondopati4@yahoo.co.id </li>
				</ul>
			</div>
			</div>
			</div> <!-- nanti habpus -->
		</div>

      <footer>
      	<div class="row">
	        <div class="col-sm-12">
				Copyright &copy;2017 || Sistem Pakar Penyakit Radang Tenggorokan Pada Balita
	        </div>
        </div>
        <a class="back-top" href="#">Back to Top</a>
      </footer>

  </div>
  <?= html_media('doctor-checklist-medical-cartoon-characters_fkEqkJdO_M.jpg', 'fixed-img') ?>
	</body>
<!-- Js Section -->

<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<?php foreach ($js as $file) {
	echo "\n\t\t";
	echo '<script src="'.$file.'"></script>';
}
echo "\n\t\t"; ?>
<!-- end of Js Section -->

<script>
	$('#slider').fadeslider();
</script>
</html>
