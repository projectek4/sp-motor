<div class="row">
	<div class="col-sm-12">
		<ol class="breadcrumb breadcrumb-arrow">
			<li><a href="#">Beranda</a></li>
			<?php if (is_login()): ?>
			<li><?= anchor('edit/'.print_url(1), 'Edit data', array('class'=>'active')) ?></li>
			<?php endif ?>
			<li><a class="active" href="#"><?= $title ?></a></li>
			<!--<li class="active"><span>Data</span></li>-->
		</ol>
	</div>
	<?php if (print_url(1) != 'edit'): ?>
	<div class="col-sm-12">
		<div id="slider" style="margin-top: -5px">
			<div class="logo-container">
				<?= html_media('logo.png', 'logo') ?>
			</div>
			<ul>
			<?php foreach ($slider as $print): ?>				
				<li><img src="<?= base_url('assets/media/images/slider/'.$print->media)?>" alt="<?= $print->deskripsi ?>"/></li>
			<?php endforeach ?>
			</ul>
		</div>
	</div>

	<?php endif ?>
</div>
<!--<header style="margin-bottom: 30px">
	<?= html_media('slide.jpg', 'img-responsive') ?>
</header>-->

<div style="position: relative;">
	<?php if (print_url(1) == 'edit'): ?>
		<?= form_open(current_url()) ?>
		<?= form_hidden('url', print_url(2)) ?>
		<?= $this->ckeditor->editor('content', html_entity_decode($content)) ?>
		<p></p>
		<?= form_button(array('class'=>'btn btn-lg btn-primary', 'type'=>'submit'), 'Update Data') ?>
		<?= form_close() ?>
	<?php else: ?>
		<article><?= $content ?></article>
	<?php endif ?>
</div>