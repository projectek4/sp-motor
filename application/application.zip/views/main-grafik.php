<div class="row">
	<div class="col-sm-12">
		<h4 class="chart-title">Grafik Pasien Bulan <?= id_bulan(date('m')).' '.date('Y') ?></h4>
		<div id="curve_chart"></div>
	</div>
</div>


