<div class="article">
	<h1><?= $title ?></h1>
	<span class="meta"><?= $meta ?></span>
	<article><?= $content ?></article>
</div>