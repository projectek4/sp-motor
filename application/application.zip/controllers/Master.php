<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		$this->load->database();
		$this->load->helper(array('app', 'url', 'form', 'text'));
		$this->load->model('app_model');
		$this->_init();

		if(!is_login())
			redirect('login','refresh');
	}

	private function _init()
	{
		$this->output->set_template('pakar');

		$this->load->less('jquery.ui/jquery.ui.less');
		$this->load->less('style.less');
		$this->load->js('https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js');
		$this->load->js('https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js');
		$this->load->js('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js');
		$this->load->js('https://cdnjs.cloudflare.com/ajax/libs/less.js/2.7.2/less.min.js');
	}
	public function index()
	{
		
	}
	/* ckeditor config */
	function editor($width,$height) {
		$this->ckeditor->basePath 					= base_url('assets/ckeditor/');
		$this->ckeditor->config['toolbar']	= 'Basic';
		$this->ckeditor->config['language'] = 'en';
		$this->ckeditor->config['width'] 		= $width;
		$this->ckeditor->config['height'] 	= $height;

		/* edit config.php di assets/ckfinder/config.php line 64 */
		
		$this->ckfinder->SetupCKEditor($this->ckeditor, '../../../assets/ckfinder');
	}
	public function detail()
	{
		$this->load->library(array('ckeditor','ckfinder', 'form_validation'));
		$width 	= '100%';
		$height = '200px';
		$this->editor($width,$height);

		$table 	= print_url(3);
		$id 		= print_url(4);

		if(print_url(3) == 'penyakit') {
			$this->form_validation->set_rules('nama', 'nama penyakit', 'trim|required');
			$this->form_validation->set_rules('solusi', 'pengobatan penyakit', 'trim|required|min_length[20]');
		} else {
			$this->form_validation->set_rules('nilai', 'nilai certanty factor', 'trim|required|callback_check_relasi');
		}
		$this->form_validation->set_rules('definisi', 'definisi penyakit', 'trim|required|min_length[20]');
		$this->form_validation->set_error_delimiters('<div class="error text-danger" style="font-size:11px;"><i>', '</i></div>');
		if ($this->form_validation->run() == TRUE) {
			if(print_url(3) == 'penyakit')
				$data = array('nama'=>$this->input->post('nama'),'definisi'=>$this->input->post('definisi'),'solusi'=>$this->input->post('solusi'), 'pencegahan'=>$this->input->post('pencegahan'));
			else
				$data = array('keterangan'=>$this->input->post('definisi'));

			/* update relasi */
			if (print_url(3) == 'gejala')
				$this->app_model->update_field('relasi', array('presentase'=>$this->input->post('nilai')), array('penyakit'=>1, 'gejala'=>$this->input->post('id')));

			$this->app_model->update_field($table, $data, array('id'=>$this->input->post('id')));
			redirect('pakar/'.print_url(3),'refresh');
		} else {
			//$data['detail'] = $this->app_model->get_where($table, array('id'=>$id))->result();
			if(print_url(3) == 'penyakit') {
				$data['nama'] = ($this->input->post('nama')?set_value('nama'):print_data('get_where', array(print_url(3), array('id'=>$id)), 'nama'));
				$data['definisi'] = ($this->input->post('definisi')?set_value('definisi'):print_data('get_where', array(print_url(3), array('id'=>$id)), 'definisi'));
				$data['pencegahan'] = ($this->input->post('pencegahan')?set_value('pencegahan'):print_data('get_where', array(print_url(3), array('id'=>$id)), 'pencegahan'));
				$data['solusi'] = ($this->input->post('solusi')?set_value('solusi'):print_data('get_where', array(print_url(3), array('id'=>$id)), 'solusi'));
			} else {
				$data['definisi'] = ($this->input->post('definisi')?set_value('definisi'):print_data('get_where', array(print_url(3), array('id'=>$id)), 'keterangan'));
				$data['nilai'] = ($this->input->post('nilai')?set_value('nilai'):print_data('get_where', array('relasi', array('penyakit'=>1, 'id'=>$id)), 'presentase'));
			}
			//$data['pencegahan'] = $this->ckeditor->editor('pencegahan', print_data('get_where', array('penyakit', array('id'=>$id)), 'pencegahan'));
			$this->load->view('master-detail', $data);
		}
	}
	public function check_relasi()
	{
		$presentase = print_data('total_presentase', array($this->input->post('id')), 'total');
		$real 			= (int)$presentase+(int)$this->input->post('nilai');
		if($real > 100) {
			$this->form_validation->set_message('check_relasi', 'Jumlah {field} tidak boleh lebih dari 100%, total=('.$real.')');
			return FALSE;
		} else {
			return TRUE;
		}
	}
	public function delete()
	{
		$this->app_model->delete_field(print_url(3), array('id'=>print_url(4)));
		redirect('pakar/'.print_url(3),'refresh');
	}
	public function guestbook()
	{
		$this->load->helper('date_format');

		if (!empty(print_url(2))) {
			$data['detail'] = $this->app_model->get_where('guestbook', array('id'=>print_url(2)))->result();
		} else {
			$data['list'] = $this->app_model->get_all('guestbook', 10, 0, 'id', 'DESC')->result();
		}
		$this->load->view('master-guestbook', $data);
	}
	public function pengunjung()
	{
		$this->load->helper('date_format');
		
		$data['list'] = $this->app_model->get_where('analisa', array('analisa>'=>0), 10, 0, 'id', 'DESC')->result();
		$this->load->view('master-pengunjung', $data);
	}
}

/* End of file Master.php */
/* Location: ./application/controllers/Master.php */