<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		$this->load->database();
		$this->load->helper(array('app', 'url', 'date_format'));
		$this->load->model('app_model');
		$this->_init();
	}

	private function _init()
	{
		$this->output->set_template('default');

		$this->load->less('jquery.ui/jquery.ui.less');
		$this->load->less('style.less');
		$this->load->js('https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js');
		$this->load->js('https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js');
		$this->load->js('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js');
		$this->load->js('https://cdnjs.cloudflare.com/ajax/libs/less.js/2.7.2/less.min.js');
	}

	/* ckeditor config */
	function editor($width,$height) {
		$this->ckeditor->basePath 					= base_url('assets/ckeditor/');
		$this->ckeditor->config['toolbar']	= 'Basic';
		$this->ckeditor->config['language'] = 'en';
		$this->ckeditor->config['width'] 		= $width;
		$this->ckeditor->config['height'] 	= $height;

		/* edit config.php di assets/ckfinder/config.php line 64 */
		
		$this->ckfinder->SetupCKEditor($this->ckeditor, '../../../assets/ckfinder');
	}	
	public function index()
	{
		$url = 'halaman-utama.html';

		$this->load->library(array('ckeditor','ckfinder', 'form_validation'));
		$this->load->helper('form');
		$width 	= '100%';
		$height = '500px';
		$this->editor($width,$height);

		/* edit or not */
		if(print_url(1) == 'edit')
			$link = print_url(2);
		else
			$link = print_url(1);

		$this->form_validation->set_rules('content', 'isi artikel', 'trim|required');
		if ($this->form_validation->run() == TRUE) {
			$data = array('content'=>$this->input->post('content'));
			$id = array('url'=>$this->input->post('url'));
			$this->app_model->update_field('posting', $data, $id);
			redirect($this->input->post('url'),'refresh');
		} else {
			$data['title'] = print_data('get_where', array('posting', array('url'=>$url)), 'title');
			$data['slider'] = $this->app_model->get_all('slider')->result();
			$data['content'] = print_data('get_where', array('posting', array('url'=>$url)), 'content');
			$this->load->css('slider/style.css');
			$this->load->js('slider/fadeslider.js');
			$this->load->view('main-index', $data);
		}
	}
	/* (:any).html */
	public function detail()
	{
		$this->load->library(array('ckeditor','ckfinder', 'form_validation'));
		$this->load->helper('form');
		$width 	= '100%';
		$height = '500px';
		$this->editor($width,$height);

		/* edit or not */
		if(print_url(1) == 'edit')
			$link = print_url(2);
		else
			$link = print_url(1);

		$this->form_validation->set_rules('content', 'isi artikel', 'trim|required');
		if ($this->form_validation->run() == TRUE) {
			$data = array('content'=>$this->input->post('content'));
			$id = array('url'=>$this->input->post('url'));
			$this->app_model->update_field('posting', $data, $id);
			redirect($this->input->post('url'),'refresh');
		} else {
			$data['title'] = print_data('get_where', array('posting', array('url'=>$link)), 'title');
			$data['content'] = print_data('get_where', array('posting', array('url'=>$link)), 'content');
			$this->load->view('main-detail', $data);
		}
	}
	/* side news */
	public function berita()
	{
		$id = $this->input->get('berita');
		$source 	= grab_url('http://rsud.patikab.go.id/v3/index.php?page=berita&id='.$id);
		$title 		= explode('<h1 class="single-post-title">', $source);
		$title_ex	= explode('</h1>', $title[1]);
		$meta 		= explode('<p class="meta">', $source);
		$meta_ex 	= explode('</p>', $meta[1]);
		$content 	= explode('<div class="post">', $source);
		$content_ex 	= explode('<p>', $content[1]);
		$content_ex1 	= explode('</p>', $content[1]);
		$data['title'] = $title_ex[0];
		$data['meta'] = $meta_ex[0];
		$data['content'] = str_replace('../uploaded/', 'http://rsud.patikab.go.id/uploaded/', $content_ex1[1]) ;
		$this->load->view('main-berita', $data);
	}
	/* Kirim Guestbook */
	
	public function send()
	{
		$content = '<p>Terimakasih atas Kritik & Saran yg anda kirimkan saudara '.$this->input->post('nama').', kedepannya kami akan menindak lanjuti Kritik & Saran yg anda kirimkan</p>
							</br></br></br></br>
							<p><i>HUMAS RSUD Soewondo</i></p>';
		send_email($this->input->post('email'), 'Konfirmasi Kritik & Saran', $content);

		$data = array( 'id' => $this->app_model->create_id('guestbook'),
			'date'=>date('Y-m-d H:i:s'),
			'nama'=>$this->input->post('nama'),
			'email'=>$this->input->post('email'),
			'content'=>$this->input->post('konten'),
			);
		$this->app_model->add_field('guestbook', $data);
		redirect('halaman-utama.html','refresh');
	}
	public function konsultasi()
	{
		/* remove session first */
		remove_session('user');
		
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->load->css('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css');
		$this->load->js('custom.js');

		$this->form_validation->set_rules('nama', 'Nama Pasien', 'required');
		$this->form_validation->set_rules('umur', 'Umur Pasien', 'required|numeric');
		$this->form_validation->set_rules('kelamin', 'Jenis kelamin', 'required');
		$this->form_validation->set_rules('email', 'Alamat email', 'required|valid_email');
		$this->form_validation->set_rules('alamat', 'Alamat Rumah', 'required');
		$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');

		if ($this->form_validation->run()) {
			$analisa = $this->app_model->create_id('analisa');
			$data = array('id'=>$analisa,
				'nama'=>$this->input->post('nama'),
				'umur'=>$this->input->post('umur'),
				'kelamin'=>$this->input->post('kelamin'),
				'email'=>$this->input->post('email'),
				'alamat'=>$this->input->post('alamat'),
				'date'=>date('Y-m-d H:i:s'));
			$this->app_model->add_field('analisa', $data);
			add_session('user', $this->input->post('email'));
			add_session('analisa', $analisa);
			redirect('konsultasi/pertanyaan','refresh');
		} else {
			$data['title'] = 'Form Konsultasi Pakar';
			$this->load->view('main-konsultasi', $data);			
		}
	}

	/* Route['konsultasi/pertanyaan'] */
	public function pertanyaan()
	{
		$this->load->library(array('form_validation'));
		$this->load->helper('form');
		$this->load->css('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css');
		
		/* Variables */
		$tmp_gejala = $this->app_model->count_tmp('tmp_gejala', array('user'=>print_session('user')));
		
		$this->form_validation->set_rules('gejala', 'gejala', 'required');
		if ($this->form_validation->run() == TRUE) {
			/* if empty user */
			if(empty(print_session('user'))) {
				redirect('konsultasi','refresh');
			}	else {
				$data = array('id'=>$this->app_model->create_id('tmp_gejala'),
					'user'=>print_session('user'),
					'gejala'=>$this->input->post('gejala'),
					'active'=>$this->input->post('button'));
				$this->app_model->add_field('tmp_gejala', $data);
				redirect('konsultasi/pertanyaan','refresh');
			}
		} else {
			if($tmp_gejala == $this->app_model->count_rows('gejala')) {

				/*
				$analisa = '';
				foreach ($this->app_model->get_where('tmp_gejala', array('user'=>print_session('user'), 'active'=>1))->result() as $key) {
					$analisa .= $key->gejala.'|';
				}
				$this->app_model->update_field('analisa', array('gejala'=>$analisa), array('email'=>print_session('user')));
				$this->app_model->delete_tmp(array('user'=>print_session('user')));

				$gejala = explode('|', $analisa);
				$array = array();
				for ($i=0; $i < count($gejala);) { 
					$array[] = $gejala[$i++];
				}

				$total = '';
				for ($aa=0; $aa < count($array)-1;) { 
					$total += print_data('get_where', array('relasi', array('gejala'=>$array[$aa++])), 'presentase');
				}

				$content = '';
				$content .= '<h3 style="position:relative;width:100%;text-align:center">Hasil Analisa Sistem Pakar</h3>
				<p>Gejala-gejala yang dialami:</p><ol>';
				for ($c=0; $c < count($array)-1; ) { 
					$content .= '<li>'.print_data('get_where', array('gejala', array('id'=>$array[$c++])), 'keterangan').'</li>';
				}
				$content .= '</ol><p>Berdasarkan gejala-gejala yg telah diinputkan, menurut perhitungan Sistem besar kemungkinan pasien terkena penyakit Radang tenggorokan adalah '.$total.'%</p>';
				send_email(print_session('user'), 'Hasil Analisa Sistem Pakar', $content);
				redirect('konsultasi/analisa','refresh');

				*/
				foreach ($this->app_model->get_all('tmp_gejala')->result() as $cetak) {
					foreach ($this->app_model->get_where('relasi',array('active'=>1, 'gejala' =>$cetak->gejala))->result() as $key) {
						if ($this->app_model->check_exist('tmp_penyakit', array('user' => print_session('user'),'penyakit' => $key->penyakit)) == FALSE) {
							$this->app_model->add_field('tmp_penyakit', array('user'=>print_session('user'), 'penyakit'=>$key->penyakit));
						}
					}
				}
				$gejala 				= '';
				$penyakit 			= '';
				foreach ($this->app_model->get_where('tmp_gejala', array('user'=>print_session('user'), 'active'=>1))->result() as $key) {
					$gejala 		.= $key->gejala.'+';
				}
				foreach ($this->app_model->get_where('tmp_penyakit', array('user'=>print_session('user')))->result() as $key) {
					$penyakit 	.= $key->penyakit.'+';
				}
				/* Menghitung analisa */	
				$str_penyakit 		= explode('+',$penyakit); 		/* daftar penyakit pasien */
				$str_gejala 			= explode('+',$gejala);				/* daftargejala pasien */

				$nomor 						= 0;
				$count_gejala 		= count($str_gejala) - 1; /* jumlah gejala */
				/*for ($i=0; $i < $count_gejala; ) {
					$nomor += $str_percaya[$i++];
				}*/
				//$ting_per 				= ($nomor/$count_gejala);
				$final 						= array();
				$nilai_persentase	= array();
				for ($i=0; $i < count($str_penyakit)-1;) {
					$tambah 					= $i++;
					$gejala_penyakit 	= array();
					$gejala_pasien		= array();
					$gejala_persen 		= array();

					foreach ($this->app_model->get_where('relasi',array('active'=>1, 'penyakit'=>$str_penyakit[$tambah]))->result() as $key) {
						$gejala_penyakit[] = $key->gejala;
					}		
					for ($i2=0; $i2 < count($str_gejala) - 1 ;)  {
						$tambah_gejala_urut = $i2++;
						$gejala_pasien[] = $str_gejala[$tambah_gejala_urut];
						$gejala_persen[] = print_data('get_where', array('relasi', array('penyakit'=>$str_penyakit[$tambah], 'gejala'=>$str_gejala[$tambah_gejala_urut])), 'presentase');
					}
					$nn = $str_penyakit[$tambah];
					$nilai_persentase[$nn] = array_sum($gejala_persen);
				
				}
					// membandingkan 2 array
					//$jum_gejala_cocok 		= count(array_intersect($gejala_penyakit,$gejala_pasien));
					//$jum_gejala_penyakit	= $this->app_model->count_rows('relasi', array('penyakit'=>$str_penyakit[$tambah]));
					//$persen_sakit = ($jum_gejala_cocok * 100) / ($jum_gejala_penyakit * 1) ;
					//$a = $jum_gejala_cocok;
					//$b = jumlah_gejala($str_penyakit[$tambah]);
					//$c = @($ting_per)*@($jum_gejala_cocok/$jum_gejala_penyakit*100);
					//$total_gejala = $this->app_model->count_rows('gejala');

					 //$semua = array_sum($gejala_persen);

					//$final[$str_penyakit[$tambah]] = $semua; arsort($final);
					arsort($nilai_persentase);

					
					$eeee 													= array_keys($nilai_persentase);
					$final_sakit 										= $eeee[0]; 
					$analisa_percaya = $nilai_persentase[$final_sakit];

					$id_periksa = $this->app_model->create_id('analisa');
					$this->app_model->delete_tmp(array('user'=>print_session('user')));
					$this->app_model->delete_tmp_penyakit(array('user'=>print_session('user')));
					$this->app_model->update_field('analisa', array('penyakit'=>$penyakit, 'gejala'=>$gejala, 'percaya'=>$analisa_percaya,  'date'=>date('Y-m-d H:i:s'), 'analisa'=>$final_sakit), array('id'=>print_session('analisa')));
					$content = '';
					$content .= '<h3 style="position:relative;width:100%;text-align:center">Hasil Analisa Sistem Pakar</h3>
					<p>Gejala-gejala yang dialami:</p><ol>';
					for ($c=0; $c < count($gejala_pasien)-1; ) { 
						$content .= '<li>'.print_data('get_where', array('gejala', array('id'=>$gejala_pasien[$c++])), 'keterangan').'</li>';
					}
					$content .= '</ol><p>Berdasarkan gejala-gejala yg telah diinputkan, menurut perhitungan Sistem besar kemungkinan pasien terkena penyakit '.print_data('get_where', array('penyakit', array('id'=>$final_sakit )), 'nama').' dengan nilai: '.$analisa_percaya.'</p>';
					send_email(print_session('user'), 'Hasil Analisa Sistem Pakar', $content);
					redirect('konsultasi/analisa','refresh');

			}
			$data['title'] = 'Daftar Pertanyaan';
			$data['id'] = print_data('get_where', array('gejala', array('id'=>($tmp_gejala+1))), 'id');
			$data['pertanyaan'] = str_replace(array('<p>', '</p>'),array('<p>Apakah Pasien mengalami ','?</p>'),  print_data('get_where', array('gejala', array('id'=>($tmp_gejala+1))), 'keterangan'));
			$this->load->view('main-pertanyaan', $data);
		}
	}
	public function analisa()
	{
		/* Buat fungsi kirim email */
		echo print_session('analisa');
		$gejala = explode('+', print_data('get_where', array('analisa', array('id'=>print_session('analisa'))), 'gejala'));
		$array = array();
		for ($i=0; $i < count($gejala);) { 
			$array[] = $gejala[$i++];
		}

		$data['title'] = 'Analisa Sistem Pakar';
		//$data['gejala'] = $this->app_model->get_all('gejala')->result();
		$data['gejala'] = $array; /* array gejala */
		$this->load->view('main-analisa', $data);
	}
	/* Admin section */
	public function login()
	{
		if(is_login())
			redirect('pakar/penyakit','refresh');

		$this->output->set_template('login');
		$this->load->css('https://fonts.googleapis.com/css?family=Roboto+Mono:400');
		$this->load->less('bootstrap/less/bootstrap.less');
		$this->load->js('https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js');
		$this->load->js('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js');
		$this->load->js('https://cdnjs.cloudflare.com/ajax/libs/less.js/2.7.2/less.min.js');
		$this->load->library(array('passwordhash','form_validation'));
		$this->load->helper(array('html', 'cookie'));

		$this->form_validation->set_rules('username', 'nama pengguna', 'trim|required|callback_login_check');
		$this->form_validation->set_rules('password', 'kata sandi', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="error text-danger">', '</div>');

		if ($this->form_validation->run() == TRUE) {
			add_session('id', print_data('get_where', array('user', array('username'=>$this->input->post('username'))), 'id'));
			$cookie = encrypt_this(date('YmdHis'));
			add_cookie('login', $cookie);
			$this->app_model->update_field('user', array('cookie'=>$cookie, 'date'=>date('Y-m-d H:i:s')), array('id'=>print_session('id')));
			redirect('pakar/penyakit','refresh');
		} else {
			$data['pass'] = $this->passwordhash->HashPassword('admin12345');
			$this->load->view('main-login', $data);
		}
	}
	function login_check()
	{
		$this->load->library('passwordhash');

		$user = $this->input->post('username');
		$pass = $this->input->post('password');

		if(empty($user)) {
			$this->form_validation->set_message('login_check', 'Bidang {field} dibutuhkan.');
			return FALSE;
		}	elseif($this->app_model->check_exist('user', array('username'=>$user)) == FALSE) {
			$this->form_validation->set_message('login_check', 'Nama Pengguna tidak terdaftar dalam basis data.');
			return FALSE;
		} elseif ($this->app_model->check_exist('user', array('username'=>$user)) == TRUE && $this->app_model->check_exist('user', array('username'=>$user, 'active'=>1)) == FALSE) {
			$this->form_validation->set_message('login_check', 'Status Pengguna sedang tidak aktif.');
			return FALSE;
		} elseif ($this->app_model->check_exist('user', array('username'=>$user)) == TRUE && $this->app_model->check_exist('user', array('username'=>$user, 'active'=>1)) == TRUE && $this->passwordhash->CheckPassword($pass, print_data('get_where', array('user', array('username'=>$user)), 'password')) == FALSE) {
			$this->form_validation->set_message('login_check', 'Kata sandi tidak sesuai dengan nama pengguna.');
			return FALSE;
		} else {
			return TRUE;
		}
	}
	public function logout()
	{
		remove_session('id');
		remove_cookie('login');
		redirect('','refresh');
	}
	public function pakar()
	{
		$this->load->helper('text');
		$this->output->set_template('pakar');
		$this->load->less('style.less');
		$this->load->js('https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js');
		$this->load->js('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js');
		$this->load->js('https://cdnjs.cloudflare.com/ajax/libs/less.js/2.7.2/less.min.js');
		$data['daftar'] = $this->app_model->get_all(print_url(2))->result();
		$this->load->view('main-pakar', $data);
	}
	public function grafik()
	{
		$this->load->js('https://www.gstatic.com/charts/loader.js');
		$this->output->set_template('pakar');
		$this->load->view('main-grafik');
	}
	public function ajax_chart()
	{
		$this->output->unset_template();
		$return = array();
		foreach ($this->app_model->distinct_analisa_month()->result() as $key) {
			$return[] = array($key->tanggal, $this->app_model->count_rows('analisa', array('day(date)'=>$key->tanggal,'month(date)'=>date('m'), 'year(date)'=>date('Y'))));
		}
		echo json_encode($return);
	}
}


