<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


if (! function_exists('full_date'))
{
	function full_date($date)
	{
		$data 	= gmdate($date, time()+60*60*8);
		$format	= explode(" ",$data);

		$a 		= $format[0];
		$b 		= $format[1];
		$jam 	= explode(':', $b);

		if ($jam[0] < 12) {
			$ampm = 'AM';
			$jamm = $jam[0];
		}
		else {
			$ampm = 'PM';
			$jamm = $jam[0] - 12;
		}

		$a_ 		= explode('-', $a);
		$hari 		= hari($format[0]);
		$tgl 		= $a_[2];
		if(system_language() == 'en') {$bulan = en_bulan($a_[1]);} else {$bulan 		= id_bulan($a_[1]);};
		$tahun 		= $a_[0];

		if(system_language() == 'en')
			return $hari.', '.$bulan.' '.$tgl.' '.$tahun.', '.$jamm.':'.$jam[1].' '.$ampm;
		else
			return $hari.', '.$tgl.' '.$bulan.' '.$tahun.' - '.$jam[0].':'.$jam[1];
	}
}

if (! function_exists('short_date'))
{
	function short_date($date)
	{
		$data 		= gmdate($date, time()+60*60*8);
		$format	= explode(" ",$data);

		$a 		= $format[0];
		$b 		= $format[1];

		$a_ 		= explode('-', $a);
		$hari 		= hari($format[0]);
		$tgl 		= $a_[2];
		if(system_language() == 'en') {$bulan = en_bulan($a_[1]);} else {$bulan = id_bulan($a_[1]);};
		$tahun 		= $a_[0];

		return $tgl.' '.$bulan.' '.$tahun;
	}
}




if ( ! function_exists('id_bulan'))
{
	function id_bulan($bln)
	{
		switch ($bln)
		{
			case 1:
				return "Januari";
				break;
			case 2:
				return "Februari";
				break;
			case 3:
				return "Maret";
				break;
			case 4:
				return "April";
				break;
			case 5:
				return "Mei";
				break;
			case 6:
				return "Juni";
				break;
			case 7:
				return "Juli";
				break;
			case 8:
				return "Agustus";
				break;
			case 9:
				return "September";
				break;
			case 10:
				return "Oktober";
				break;
			case 11:
				return "November";
				break;
			case 12:
				return "Desember";
				break;
		}
	}
}
if ( ! function_exists('en_bulan'))
{
	function en_bulan($bln)
	{
		switch ($bln)
		{
			case 1:
				return "January";
				break;
			case 2:
				return "February";
				break;
			case 3:
				return "March";
				break;
			case 4:
				return "April";
				break;
			case 5:
				return "May";
				break;
			case 6:
				return "June";
				break;
			case 7:
				return "July";
				break;
			case 8:
				return "August";
				break;
			case 9:
				return "September";
				break;
			case 10:
				return "October";
				break;
			case 11:
				return "November";
				break;
			case 12:
				return "December";
				break;
		}
	}
}
if ( ! function_exists('hari'))
{
	function hari($tanggal)
	{
		$ubah 		= gmdate($tanggal, time()+60*60*8);
		$pecah 		= explode("-",$ubah);
		$tgl 		= $pecah[2];
		$bln 		= $pecah[1];
		$thn 		= $pecah[0];

		$nama 		= date("l", mktime(0,0,0,$bln,$tgl,$thn));
		$nama_hari 	= "";
		if($nama=="Sunday") {$nama_hari="Minggu";}
		else if($nama=="Monday") {$nama_hari="Senin";}
		else if($nama=="Tuesday") {$nama_hari="Selasa";}
		else if($nama=="Wednesday") {$nama_hari="Rabu";}
		else if($nama=="Thursday") {$nama_hari="Kamis";}
		else if($nama=="Friday") {$nama_hari="Jumat";}
		else if($nama=="Saturday") {$nama_hari="Sabtu";}

		if(system_language() == 'en')
			return $nama;
		else
			return $nama_hari;
	}
}
