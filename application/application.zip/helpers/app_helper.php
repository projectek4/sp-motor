<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if (! function_exists('html_favicon')) {
	function html_favicon()
	{
		return '<link rel="icon" type="image/png" href="'.base_url('assets/media/images/favicon.png').'">';
	}
}
if (! function_exists('html_css')) {
	function html_css($value)
	{
		return '<link rel="stylesheet" type="text/css" href="'.base_url('assets/'.$value).'" media="all">';
	}
}
if (! function_exists('html_less')) {
	function html_less($value)
	{
		return '<link rel="stylesheet/less" type="text/css" href="'.base_url('assets/'.$value).'" media="all">';
	}
}
if (! function_exists('html_js')) {
	function html_js($value)
	{
		return '<script src="'.base_url('assets/'.$value).'" type="text/javascript"></script>';
	}
}
if (! function_exists('html_media')) {
	function html_media($value, $class='', $alt='')
	{
		if(!empty($class))
			$class = 'class='.$class;
		else
			$class = '';
		return '<img '.$class.' src="'.base_url('assets/media/images/'.$value).'" alt="'.$alt.'">';
	}
}
if (! function_exists('fontawesome')) {
	function fontawesome($value)
	{
		//return '<i class="fa fa-'.$value.'"></i>';
		return '<i class="fa fa-'.$value.'" aria-hidden="true"></i> ';
	}
}
if (! function_exists('bs_pagination')) {
	function bs_pagination($table,$where, $level, $url, $per_page)
	{
		$CI =& get_instance();
		$CI->load->library('pagination');

		$config['uri_segment']      	= $level;
		$config['base_url']         	= base_url($url.'/');
		$config['total_rows']       	= $CI->app_model->count_rows($table, $where);
		$config['per_page']         	= $per_page;
		$config['full_tag_open']    	= '<ul class="pagination">';
		$config['full_tag_close']   	= '</ul>';
		$config['first_link']       	= '&laquo&laquo';
		$config['last_link']        	= '&raquo&raquo';
		$config['first_tag_open']   	= '<li>';
		$config['first_tag_close']  	= '</li>';
		$config['prev_link']        	= '&laquo';
		$config['prev_tag_open']    	= '<li class="prev">';
		$config['prev_tag_close']   	= '</li>';
		$config['next_link']        	= '&raquo';
		$config['next_tag_open']    	= '<li>';
		$config['next_tag_close']   	= '</li>';
		$config['last_tag_open']    	= '<li>';
		$config['last_tag_close']   	= '</li>';
		$config['cur_tag_open']     	= '<li class="active"><a href="#">';
		$config['cur_tag_close']    	= '</a></li>';
		$config['num_tag_open']     	= '<li>';
		$config['num_tag_close']    	= '</li>';

		$CI->pagination->initialize($config);
		return $CI->pagination->create_links();
	}
}
if (! function_exists('nav_menu')) {
	function nav_menu($array=array(), $active='')
	{
		$CI =& get_instance();
		$CI->load->helper('url');

		$return = '<ul class="nav navbar-nav">';
		foreach ($array as $x=>$x_value) {
			if (! empty($active) && $active == $x)
				$nav = 'class="active"';
			else
				$nav = '';
			$return .= '<li '.$nav.' >'.anchor($x, $x_value).'</li>';
		}
		$return .= '</ul>';
		return $return;
	}
}
if (! function_exists('not_mobile')) {
	function not_mobile()
	{
		$CI =& get_instance();
		$CI->load->library('user_agent');
		if ($CI->agent->is_mobile() == FALSE)
			return TRUE;
		else
			return FALSE;
	}
}
if (! function_exists('greeting')) {
	function greeting($value='')
	{
		date_default_timezone_set('Asia/Jakarta');
		$b 		= time();
		$hour 	= date("g", $b);
		$m    	= date("A", $b);
		if ($m == "AM") {
			if ($hour == 12) {
				return "Selamat Siang!";
			} elseif ($hour < 4) {
				return "Selamat Siang!";
			} elseif ($hour > 3) {
				return "Selamat Pagi!";
			}
		}
		elseif ($m == "PM") {
			if ($hour == 12) {
				return "Selamat Malam!";
			} elseif ($hour < 6) {
				return "Selamat Siang!";
			} elseif ($hour > 5) {
				return "Selamat Malam!";
			}
		}
		//return date("A", time());
	}
}
if (! function_exists('is_login')) {
	function is_login()
	{
		$CI =& get_instance();
		$CI->load->library('session');
		$CI->load->helper('cookie');
		$CI->load->model('app_model');
		$id = print_data('get_where', array('user', array('cookie'=>get_cookie('login'))), 'id');
		if(empty($CI->session->userdata('id')) && !empty($CI->app_model->check_exist('user', array('cookie'=>get_cookie('login'))))) {
			$data = array('id'=>$id,
				'nama'=>print_data('get_where', array('user', array('id'=>$id)), 'nama')
				);
			$CI->session->set_userdata($data);
		}
		if (!empty($CI->session->userdata('id')) OR !empty($CI->app_model->check_exist('user', array('cookie'=>get_cookie('login')))))
			return TRUE;
		else
			return FALSE;
	}
}
if(! function_exists('encrypt_this')) {
	function encrypt_this($value)
	{		
		$CI =& get_instance();
		$CI->load->library('passwordhash');
		return $CI->passwordhash->HashPassword($value);
	}
}
if (! function_exists('add_session')) {
	function add_session($session, $value) {
		$CI =& get_instance();
		$CI->load->library('session');
		$CI->session->set_userdata($session, $value);
	}
}
if (! function_exists('add_cookie')) {
	function add_cookie($cookie, $value, $exp = 86500) {
		$CI =& get_instance();
		$CI->load->helper('cookie');
		set_cookie(array('name'=>$cookie, 'value'=>$value, 'expire'=>$exp));
	}
}
if (! function_exists('remove_session')) {
	function remove_session($session) {
		$CI =& get_instance();
		$CI->load->library('session');
		$CI->session->unset_userdata($session);
	}
}
if (! function_exists('remove_cookie')) {
	function remove_cookie($value)
	{		
		$CI =& get_instance();
		$CI->load->helper('cookie');
		delete_cookie($value);
	}
}
if (! function_exists('print_session')) {
	function print_session($value)
	{
		$CI =& get_instance();
		$CI->load->library('session');
		return $CI->session->userdata($value);
	}
}
if (! function_exists('print_cookie')) {
	function print_cookie($value)
	{
		$CI =& get_instance();
		$CI->load->helper('cookie');
		return get_cookie($value);
	}
}
if (! function_exists('print_url')) {
	function print_url($value)
	{
		$CI =& get_instance();
		return $CI->uri->segment($value);
	}
}
if (! function_exists('print_ip'))
{
	function print_ip()
	{
		$CI =& get_instance();
		$ip = $CI->input->ip_address();
		return $ip;
	}
}
if (! function_exists('system_language'))
{
	function system_language()
	{
		if (empty(print_cookie('bahasa')))
			return 'id';
		else
			return print_cookie('bahasa');
	}
}
if (! function_exists('print_data')) {
	function print_data($func, $args = array(), $field_name = '')
	{
		$CI =& get_instance();
		$model = 'app_model';
		$CI->load->model($model);

		$retrieve = call_user_func_array(array($CI->$model, $func), $args)->row_array();
		if (empty($field_name))
			return call_user_func_array(array($CI->$model, $func), $args)->result();
		else
			return isset($retrieve[$field_name]) ? $retrieve[$field_name] : '';
	}
}
if (! function_exists('array_bulan')) {
	function array_bulan()
	{
		return array('', 'januari', 'februari', 'maret', 'april', 'mei', 'juni', 'juli', 'agustus', 'september', 'oktober', 'november', 'desember');
	}
}
if (! function_exists('ran_upload')) {
	function ran_upload()
	{
		$CI =& get_instance();
		$date = str_replace('-', '', date('Y-m-d'));
		return 'ekafiles'.$date.$CI->app_model->create_id('posting');
	}
}
if (! function_exists('grab_url')) {
	function grab_url($url){
		$data = curl_init();

		curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($data, CURLOPT_URL, $url);

		$hasil = curl_exec($data);
		curl_close($data);
		return $hasil;
	}
}
if (! function_exists('send_email')) {
	function send_email($to, $subject, $content, $sender='')
	{
		$CI =& get_instance();
		$CI->load->library('email');
		$config['protocol'] 	= "smtp";
		$config['smtp_host'] 	= "ssl://mail.mlayu.id";
		$config['smtp_port'] 	= "465";
		$config['smtp_user'] 	= "demo@mlayu.id";
		$config['smtp_pass'] 	= "demo12345";
		$config['charset'] 		= "utf-8";
		$config['mailtype'] 	= "html";
		$config['newline'] 		= "\r\n";
		$CI->email->initialize($config);
		$CI->email->from('admin@website.id', 'Administrator');
		$CI->email->to($to);
		$CI->email->subject($subject);
		$CI->email->message($content);
		$CI->email->send();
	}
}
if (! function_exists('level')) {
	function level($value)
	{
		switch ($value) {
			case '1':
				return 'Administrator System';
				break;
			
			default:
				return 'Uknown Level';
				break;
		}
	}
}

if (! function_exists('rupiah')) {
	function rupiah($nilai, $pecahan = 0)
	{
		return 'IDR '.number_format($nilai, $pecahan, ',', '.');
	}
}

if (! function_exists('cek_hari')) {
	function cek_hari($tanggal)
	{
		$day = date('D', strtotime($tanggal));
		$dayList = array(
			'Sun' => 'Minggu',
			'Mon' => 'Senin',
			'Tue' => 'Selasa',
			'Wed' => 'Rabu',
			'Thu' => 'Kamis',
			'Fri' => 'Jumat',
			'Sat' => 'Sabtu'
		);
		echo $dayList[$day];
	}
}

if(! function_exists('hari')) {
	function hari($value)
	{
		switch ($value) {
			case '1':
				return 'Senin';
				break;
			case '2':
				return 'Selasa';
				break;
			case '3':
				return 'Rabu';
				break;
			case '4':
				return 'Kamis';
				break;
			case '5':
				return 'Jumat';
				break;
			case '6':
				return 'Sabtu';
				break;
			case '7':
				return 'Minggu';
				break;
		}
	}
}



